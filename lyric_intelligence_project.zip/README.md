# Lyric Intelligence – Predicting Viral Music Trends

Sprint 3: Jose's Journey into Predictive Modeling