# Global config variables
RAW_DATA_PATH = 'data/raw/universal_top_spotify_songs.csv'